===============
This is an example project that is used to demonstrate how to publish
Python packages on PyPI. To take a look at the step by step guide on how to 
do so, make sure you read `my article on Towards Data Science <https://towardsdatascience.com/how-to-upload-your-python-package-to-pypi-de1b363a1b3>`_.
