

def hello_world_func():
    print("Hello World")